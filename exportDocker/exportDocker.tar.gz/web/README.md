npx hardhat compile
npx hardhat node
npx hardhat deploy
npm run start